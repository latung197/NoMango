﻿using System;
using System.Collections.Generic;

namespace MISA.CukCuk.Models
{
    public partial class Ethnic
    {
        public Guid EthnicId { get; set; }
        public string EthnicName { get; set; }
    }
}
