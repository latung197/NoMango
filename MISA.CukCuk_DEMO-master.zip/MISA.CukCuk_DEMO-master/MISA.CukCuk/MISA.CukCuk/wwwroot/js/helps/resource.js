﻿var Enum = {
    FormMode: {
        Add: 1,
        Duplicate: 2,
        Edit: 3,
        Delete: 4,
        Refresh: 5
    },

    Gender: {
        Male: 1,
        Female: 0,
        Other: 2
    }

}
var Resource = {
    Language: {
        VI: {
            AddNew:"Thêm mới"
        },
        EN: {
            AddNew: "hdhdhfdhhjdghj <- (Đây là tiếng Thái)"
        },
        LAO: {

        },
        THAI: {

        }
    }
}