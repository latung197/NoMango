﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace Worker.Application.CustomModels.Dtos
{
    [Description("Ecu Data")]
    public class EcuDataDto
    {
        [Required]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Description("EcuDataID")]
        public int EcuDataID { get; set; }
        [Description("Ngày giờ")]
        public DateTime? DateManufacture { get; set; }
        [Description("Mã NG")]
        public string NgCode { get; set; }//EnumCommon. 0 is NG, 1 is OK
        [Description("Ghi chú")]
        [MaxLength(200)]
        public string? Note { get; set; }
        [Description("Kết quả")]
        public int Result { get; set; }//EnumCommon. 0 is NG, 1 is OK
        [Description("Mã HU")]
        [MaxLength(20)]
        public string? HUCode { get; set; }
        [Description("In laze")]
        [MaxLength(30)]
        public string? LaserPrinting { get; set; }
        [Description("Valid flag")]
        public int ValidFlg { get; set; } = 1;//EnumCommon
    }
}
